<?php

    $teamleader= $_SESSION['user']; ?>

<?php 

global $teamA,$teamB,$teamC, $SellA, $SellB,$SellC;



$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teamleader' AND TeamABC='TeamA' ";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}
    
    
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}



 
$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamA+= '1';
    //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellA+= '1';}

}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}




//BBBBBBBBBBBBBBBBBBBB

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teamleader' AND TeamABC='TeamB' ";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamB+= '1';

   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellB+= '1';
   }


  


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';


   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellB+= '1';
   }



$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellB+= '1';
   }


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';

   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellB+= '1';
   }

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';

   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellB+= '1';
   }

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';

   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellB+= '1';
   }

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellB+= '1';
   }


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';

   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellB+= '1';
   }

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellB+= '1';
   }


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamB+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) { $SellB+= '1';}


}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



//CCCCCCCCCC


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teamleader' AND TeamABC='TeamC' ";
$query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $teauser=$team['UserName'];
       $teamC+= '1';


   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellC+= '1';
   }



$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellC+= '1';
   }


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamC+= '1';

   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellC+= '1';
   }


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamC+= '1';

   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellC+= '1';
   }


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {
   $teauser=$team['UserName'];
   $teamC+= '1';

   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {
       $SellC+= '1';
   }


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}


$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}

$sql = "SELECT * FROM teamtable WHERE TeamLeaders='$teauser'";
$query = mysqli_query($conn,$sql);
foreach ($query as $team) {$teauser=$team['UserName']; $teamC+= '1';
   //pakeg
    $sql = "SELECT * FROM package WHERE PackageUserId='$teauser'";
    $query = mysqli_query($conn,$sql);
    foreach ($query as $team) {$SellC+= '1';}






}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}



?>




